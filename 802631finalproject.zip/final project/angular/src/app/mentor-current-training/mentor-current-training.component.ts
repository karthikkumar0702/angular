import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Mentorcurrent} from '../mentor-current';
import { mentorcurrentservice} from '../mentor-current.service';
@Component({
  selector: 'app-mentor-current-training',
  templateUrl: './mentor-current-training.component.html',
  styleUrls: ['./mentor-current-training.component.css']
})
export class MentorCurrentTrainingComponent implements OnInit {
  mentorcurrent: Observable<[Mentorcurrent]>;

  constructor(private  mentorCurrentService: mentorcurrentservice) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData(){
    this.mentorcurrent= this.mentorCurrentService.getCurrentTraining();
  }

}
