import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class mentorcompletedservice {
 
   private baseUrl = 'http://localhost:8080/api/mentorservice/mentorcompleted/findcompleted';
 
  constructor(private http: HttpClient) { }
 
  getCompletedTraining(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}
