export class Mentorcompleted{
    id:number;
    username:string;
    technology:string;
    duration:number;
}