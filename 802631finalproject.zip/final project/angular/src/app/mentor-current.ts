
export class Mentorcurrent{
    id:number;
    completedduration:number;
    pendingduration:number;
   technology:string;
   username:string;
}