export class Usercompleted{
    id:number;
    username:string;
    technology:string;
    duration:number;
}