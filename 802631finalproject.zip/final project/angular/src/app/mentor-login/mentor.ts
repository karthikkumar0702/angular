export class Mentor{
    username:string;
    firstname:string;
    lastname:string;
    password:string;
    contactnumber:number;
    facilities:string;
    experience:string;
}