import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { registerService } from '../register.service';
import { Role } from '../user-login/role';
import { MentorserviceService } from '../mentorservice.service';
import { Userregister } from '../user-login/userregister';
import { MentorSignupComponent } from '../mentor-signup/mentor-signup.component';
import { Mentor } from './mentor';



@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.css']
})
export class MentorLoginComponent implements OnInit {
   mentor: Mentor =  new Mentor();
   userregister:Userregister=new Userregister;
   submitted=false;
   private error=false;
   username:string;
   firstname:string;
   lastname:string;
   password:string;
   contactnumber:number;
   facilities:string;
   experience:string;
   role:Role=new Role();
   private id=2;
   private rolename="mentor";
  constructor(private trainer:registerService) { }
  ngOnInit() {
  }
  save(){
    if(this.username==null || this.password==null ||this.firstname==null||this.lastname==null||this.contactnumber==null||this.facilities==null||this.experience==null)
    {
      this.error=true;
    }
    else{
      this.mentor.password=this.password;
      this.mentor.username=this.username;
      this.mentor.firstname=this.firstname;
      this.mentor.lastname=this.lastname;
      this.mentor.contactnumber=this.contactnumber;
      this.mentor.experience=this.experience;
      this.mentor.facilities=this.facilities;


      this.role.id=this.id;
      this.role.role=this.rolename;
      this.userregister.role=this.role;


        this.trainer.createMentor(this.mentor).subscribe(data => console.log(data),error =>console.log(error));

        this.userregister.username=this.username;
        this.userregister.password=this.password;
        this.trainer.createUserRegister(this.userregister)
          .subscribe(data => console.log(data), error =>console.log(error));
          this.submitted= true;
          this.error=false
    }

  }
}