import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main/main.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { AdminEditUserComponent } from './admin-edit-user/admin-edit-user.component';
import { AdminSignupComponent } from './admin-signup/admin-signup.component';
import { AdminTechnologyComponent } from './admin-technology/admin-technology.component';
import { MainSearchTrainingComponent } from './main-search-training/main-search-training.component';
import { MentorCompletedTrainingComponent } from './mentor-completed-training/mentor-completed-training.component';
import { MentorCurrentTrainingComponent } from './mentor-current-training/mentor-current-training.component';
import { MentorEditSkillsComponent } from './mentor-edit-skills/mentor-edit-skills.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { MentorStatusComponent } from './mentor-status/mentor-status.component';
import { UserCompletedTrainingComponent } from './user-completed-training/user-completed-training.component';
import { UserCurrentTrainingComponent } from './user-current-training/user-current-training.component';
import { UserSearchTrainingComponent } from './user-search-training/user-search-training.component';
import { UserSignupComponent } from './user-signup/user-signup.component';


const routes: Routes = [
  {path:'',component:MainComponent},
  {path:'user-login',component:UserLoginComponent},
  {path:'admin-edit-user',component:AdminEditUserComponent},
  {path:'admin-signup',component:AdminSignupComponent},
  {path:'admin-technology',component:AdminTechnologyComponent},
  {path:'main-search-training',component:MainSearchTrainingComponent},
  {path:'mentor-completed-training',component:MentorCompletedTrainingComponent},
  {path:'mentor-current-training',component:MentorCurrentTrainingComponent},
  {path:'mentor-edit-skills',component:MentorEditSkillsComponent},
  {path:'mentor-login',component:MentorLoginComponent},
  {path:'mentor-signup',component:MentorSignupComponent},
  {path:'mentor-status',component:MentorStatusComponent},
  {path:'user-completed-training',component:UserCompletedTrainingComponent},
  {path:'user-current-training',component:UserCurrentTrainingComponent},
  {path:'user-login',component:UserLoginComponent},
  {path:'user-search-training',component:UserSearchTrainingComponent},
  {path:'user-signup',component:UserSignupComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
