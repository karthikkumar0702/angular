import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-search-training',
  templateUrl: './user-search-training.component.html',
  styleUrls: ['./user-search-training.component.css']
})
export class UserSearchTrainingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
