import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSearchTrainingComponent } from './user-search-training.component';

describe('UserSearchTrainingComponent', () => {
  let component: UserSearchTrainingComponent;
  let fixture: ComponentFixture<UserSearchTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserSearchTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSearchTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
