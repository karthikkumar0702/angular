import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-edit-user',
  templateUrl: './admin-edit-user.component.html',
  styleUrls: ['./admin-edit-user.component.css']
})
export class AdminEditUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
