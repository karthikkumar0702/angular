import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class registerService {
 private baseUrl="http://localhost:8080/api";
  constructor(private http:HttpClient) { }
  // getUser(username:string):Observable<any>{
  //   return this.http.get(`${this.baseUrl}/User/finduser/${username}`);
  // }


  createUser(user: object): Observable<object> {  
    return this.http.post(`http://localhost:8080/api/userservice/save`,user);  
  } 
  createUserRegister(userregister:object):Observable<object>{
    return this.http.post(`http://localhost:8080/api/userservice/saveuser`, userregister);
  }
  createMentor(mentor:object):Observable<object>{
    return this.http.post(`http://localhost:8080/api/mentorservice/save`,mentor);
  }
  





  getTrainer(){
  
    return this.http.get(`http://localhost:8080/api/userservice/save`);
  }
  getTechnology(){
  
    return this.http.get(`http://localhost:8080/api/userservice/save`);
  }
  getCompleted(username: string) {  
    return this.http.get(`http://localhost:8080/api/userservice/save/User/findcompleted/${username}`);  
  }
    getCurrent(username:string) {  
    return this.http.get(`${`http://localhost:8080/api/userservice/save`}/User/findcurrent/${username}`);  
  }


  getUser(username:string):Observable<any> {  
    return this.http.get(`http://localhost:8080/api/userservice/finduser/${username}`);  
  }

 
  searchMentor(technology:string):Observable<any> {  
    return this.http.get(`${`http://localhost:8080/api/userservice/save`}/course/findtechnology/${technology}`);  
  }
  searchMentortime(time:string):Observable<any> {  
    return this.http.get(`${`http://localhost:8080/api/userservice/save`}/course/findtimesearch/${time}`);  
  }
  findMentor():Observable<any> {  
    return this.http.get(`${`http://localhost:8080/api/userservice/save`}/course/findmentorlist/`);  
  }
  savecurrent(username:string,technology:string){
    return this.http.get(`${`http://localhost:8080/api/userservice/save`}/User/savecurrent/${username}/${technology}`); 
  }
 

  //ADMIN
  getTechnology1():Observable<any> {  
    return this.http.get(`${this.baseUrl}/adminservice/findadmintechnology`);  
  }
  userblock(username:string){
    return this.http.get(`${this.baseUrl}/adminservice/userblock/${username}`);

  }
  userunblock(username:string){
    return this.http.get(`${this.baseUrl}/adminservice/userunblock/${username}`);

  }
  addtechnology(technology:string,duration:string){
    return this.http.get(`${this.baseUrl}/adminservice/savetechnology/${technology}/${duration}`);
  }
  getPayment(){
    return this.http.get(`${this.baseUrl}/adminservice/findpayment`);

  }
  getUser1(){  
    return this.http.get(`${this.baseUrl}/adminservice/finduser`);  
  }
  getMentor() {  
    return this.http.get(`${this.baseUrl}/adminservice/findmentor`);  
  }

}
