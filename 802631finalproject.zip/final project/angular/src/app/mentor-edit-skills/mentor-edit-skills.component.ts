import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-edit-skills',
  templateUrl: './mentor-edit-skills.component.html',
  styleUrls: ['./mentor-edit-skills.component.css']
})
export class MentorEditSkillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
