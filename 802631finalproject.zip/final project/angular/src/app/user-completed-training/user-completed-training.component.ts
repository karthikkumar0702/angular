import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Usercompleted } from '../user-completed';
import { usercompletedservice } from '../user-completed.service';

@Component({
  selector: 'app-user-completed-training',
  templateUrl: './user-completed-training.component.html',
  styleUrls: ['./user-completed-training.component.css']
})
export class UserCompletedTrainingComponent implements OnInit {
  usercompleted: Observable<[Usercompleted]>;

  constructor(private  userCompletedService: usercompletedservice) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData(){
    this.usercompleted= this.userCompletedService.getCompletedTraining();
  }

}
