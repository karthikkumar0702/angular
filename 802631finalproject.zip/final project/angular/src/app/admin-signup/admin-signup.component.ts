import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-admin-signup',
  templateUrl: './admin-signup.component.html',
  styleUrls: ['./admin-signup.component.css']
})
export class AdminSignupComponent implements OnInit {
mailid:string;
pwd:string;
  constructor(private admin:Router) { }

  ngOnInit() {
  }
  submit(){
    if(this.mailid==null){
      alert("enter valid mail address");
    }
    else if(this.pwd==null){
      alert("enter password");
    }
    else{
      this.admin.navigate(['/admin-edit-user']);
      
    }

  }

}
