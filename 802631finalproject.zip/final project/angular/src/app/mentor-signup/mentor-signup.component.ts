import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {
  mailid:string;
  pwd:string;
  constructor(private mentor: Router) { }

  ngOnInit() {
  }

  submit(){
    if(this.mailid==null){
      alert("enter valid mail address");
    }
    else if(this.pwd==null){
      alert("enter password");
    }
    else{
      this.mentor.navigate(['/mentor-current-training']);
    }
  }
}
