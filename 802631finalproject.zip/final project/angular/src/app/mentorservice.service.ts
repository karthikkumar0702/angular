import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorserviceService {
private url="http://localhost:8080/api";
 
   
  constructor(private http:HttpClient) { }

  getTechnology():Observable<any> {  
    return this.http.get(`${this.url}/adminservice/findadmintechnology`);  
  }
  savementor(mentor:object):Observable<any>{
    return this.http.post(`${this.url}/mentorservice/save`,mentor);
  }
  savetechnology(username:string,technology:string):Observable<any>{
    return this.http.get(`${this.url}/courseservice/savetechnology/${username}/${technology}`);
  }
  savetime(username:string,time:string):Observable<any>{
    return this.http.get(`${this.url}/courseservice/savetime/${username}/${time}`);
  }
  savementorlogin(mentor:object):Observable<any>{
    return this.http.post(`${this.url}/mentorservice/savementor`,mentor);
  }
  getCompleted(username: string) {  
    return this.http.get(`${this.url}/mentorservice/findcompleted/${username}`);  
  }
    getCurrent(username:string) {  
    return this.http.get(`${this.url}/mentorservice/findcurrent/${username}`);  
  }
  getSkill(username:string){
    return this.http.get(`${this.url}/courseservice/findskill/${username}`);
  }
}
