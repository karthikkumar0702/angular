import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-status',
  templateUrl: './mentor-status.component.html',
  styleUrls: ['./mentor-status.component.css']
})
export class MentorStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
