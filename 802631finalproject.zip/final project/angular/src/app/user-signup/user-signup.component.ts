import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Userregister } from '../user-login/userregister';
import { registerService } from '../register.service';
@Component({
  selector: 'app-user-signup',
  templateUrl: './user-signup.component.html',
  styleUrls: ['./user-signup.component.css']
})
export class UserSignupComponent implements OnInit {
  username:string;
password:string;
invalidLogin :boolean=false;
 userlogin:Userregister=new Userregister();
 private error=false;

  constructor(private router:Router,private service:registerService) { }

  ngOnInit() {
  }
  validate(){
    if(this.username==null || this.password==null){
      this.error=true;
      
    }
    
  else{
    this.error=false;
    this.service.getUser(this.username).subscribe(value=>this.userlogin=value);
    if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==1){
    
  this.router.navigate(['/user-search-training']);
  this.invalidLogin = false;
    }
    else if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==2){
    
        this.router.navigate(['/mentor-completed-training']);
        this.invalidLogin = false;
          }
          else  if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==3){
    
            this.router.navigate(['/admin-technology']);
            this.invalidLogin = false;
              }
          
else{
  this.invalidLogin=true;
}
    }
  }
}
