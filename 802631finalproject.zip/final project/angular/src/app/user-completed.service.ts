import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class usercompletedservice {
 
  private baseUrl = 'http://localhost:8040/usercompleted/findcompleted';
 
  constructor(private http: HttpClient) { }
 
 
  getCompletedTraining(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}
