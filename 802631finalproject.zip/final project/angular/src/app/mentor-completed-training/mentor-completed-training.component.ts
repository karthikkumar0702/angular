import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import {Mentorcompleted} from '../mentor-completed';
import { mentorcompletedservice} from '../mentor-completed.service';

@Component({
  selector: 'app-mentor-completed-training',
  templateUrl: './mentor-completed-training.component.html',
  styleUrls: ['./mentor-completed-training.component.css']
})
export class MentorCompletedTrainingComponent implements OnInit {
 mentorcompleted: Observable<Mentorcompleted[]>;
  MentorCompletedService: any;
  constructor(private  mentorCompletedService: mentorcompletedservice) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData(){
    this.mentorcompleted= this.mentorCompletedService.getCompletedTraining();
  }

}
