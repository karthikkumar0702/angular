import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { registerService } from '../register.service';

@Component({
  selector: 'app-admin-technology',
  templateUrl: './admin-technology.component.html',
  styleUrls: ['./admin-technology.component.css']
})
export class AdminTechnologyComponent implements OnInit {
 
  
  private payment=[];
  private technology=[];
  private user=[];
  private mentor=[];
  displayvalue:boolean=false;
  displaycurrent:boolean=false;
  displaycomplete:boolean=false;
  displayaddtech:boolean=false;
  private username:string;
  private tech:string;
  private duration:string;
    constructor(private trainer:registerService,private router:ActivatedRoute) { }
  
    ngOnInit() {
      this.username=this.router.snapshot.paramMap.get('username');
    }
  
  showTech(){
    this.displayvalue=false;
    this.displaycomplete=false;
    this.displaycurrent=true;
    this.trainer.getTechnology1()
    .subscribe(value =>this.technology=value as string[]);

    
  }
  showBlock(){
    this.displayvalue=false;
    this.displaycomplete=true;
    this.displaycurrent=false;
    this.trainer.getMentor().subscribe(value=>this.mentor=value as string[]);
    this.trainer.getUser1().subscribe(value=>this.user=value as string[]);
  
   
  }
  showPayment(){
    this.displayvalue=true;
    this.displaycomplete=false;
    this.displaycurrent=false;
    this.trainer.getPayment()
    .subscribe(data =>this.payment=data as string[]);
  }
delete(username){
  
  this.trainer.userblock(username).subscribe();
    
}
unblock(username){
  this.trainer.userunblock(username).subscribe();
}
addtech(){
this.displayaddtech=true;
}
savetechnology(){
  this.trainer.addtechnology(this.tech,this.duration).subscribe();
  this.displayaddtech=false;
}
}


