import { TestBed } from '@angular/core/testing';

import { registerService } from './register.service';

describe('UserregisterService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: registerService = TestBed.get(registerService);
    expect(service).toBeTruthy();
  });
});
