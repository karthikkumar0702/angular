import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';


@Component({
  selector: 'app-main-search-training',
  templateUrl: './main-search-training.component.html',
  styleUrls: ['./main-search-training.component.css']
})
export class MainSearchTrainingComponent implements OnInit {
  course : string[];
  constructor(private httpservice : HttpClient) { }
  

  ngOnInit() {
    this.httpservice.get('../../assets/main-search-training.json').subscribe(

      data=>{
        this.course = data as string[];
      },
      (err : HttpErrorResponse) => {
        console.log(err.message);
      }
    )    

  }

}
