import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainSearchTrainingComponent } from './main-search-training.component';

describe('MainSearchTrainingComponent', () => {
  let component: MainSearchTrainingComponent;
  let fixture: ComponentFixture<MainSearchTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainSearchTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainSearchTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
