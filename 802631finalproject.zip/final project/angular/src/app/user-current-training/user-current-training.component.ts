import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Usercurrent} from '../user-current';
import { usercurrentservice} from '../user-current.service';
@Component({
  selector: 'app-user-current-training',
  templateUrl: './user-current-training.component.html',
  styleUrls: ['./user-current-training.component.css']
})
export class UserCurrentTrainingComponent implements OnInit {
  usercurrent: Observable<[Usercurrent]>;

  constructor(private  userCurrentService: usercurrentservice) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData(){
    this.usercurrent= this.userCurrentService.getCurrentTraining();
  }

}
