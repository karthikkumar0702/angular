import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminEditUserComponent } from './admin-edit-user/admin-edit-user.component';
import { AdminSignupComponent } from './admin-signup/admin-signup.component';
import { AdminTechnologyComponent } from './admin-technology/admin-technology.component';
import { MainComponent } from './main/main.component';
import { MainSearchTrainingComponent } from './main-search-training/main-search-training.component';
import { MentorCompletedTrainingComponent } from './mentor-completed-training/mentor-completed-training.component';
import { MentorCurrentTrainingComponent } from './mentor-current-training/mentor-current-training.component';
import { MentorEditSkillsComponent } from './mentor-edit-skills/mentor-edit-skills.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { MentorStatusComponent } from './mentor-status/mentor-status.component';
import { UserCompletedTrainingComponent } from './user-completed-training/user-completed-training.component';
import { UserCurrentTrainingComponent } from './user-current-training/user-current-training.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { UserSearchTrainingComponent } from './user-search-training/user-search-training.component';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    AdminEditUserComponent,
    AdminSignupComponent,
    AdminTechnologyComponent,
    MainComponent,
    MainSearchTrainingComponent,
    MentorCompletedTrainingComponent,
    MentorCurrentTrainingComponent,
    MentorEditSkillsComponent,
    MentorLoginComponent,
    MentorSignupComponent,
    MentorStatusComponent,
    UserCompletedTrainingComponent,
    UserCurrentTrainingComponent,
    UserLoginComponent,
    UserSignupComponent,
    UserSearchTrainingComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
