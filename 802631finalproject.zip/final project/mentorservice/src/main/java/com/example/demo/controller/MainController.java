package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Mentor;
import com.example.demo.model.MentorCompletedTraining;
import com.example.demo.model.MentorCurrentTraining;
import com.example.demo.service.MentorService;

@Controller
@CrossOrigin(origins="http://localhost:4200")
public class MainController {
	@Autowired
	private MentorService mentorservice;

	@PostMapping("/save")
	public @ResponseBody String saveUser(@RequestBody Mentor m) {
		mentorservice.saveMentorDetails(m);
		return "stored";
	}

	@GetMapping(path = "/saveuser/{username}/{password}")
	public @ResponseBody String user(@PathVariable String username, @PathVariable String password) {

		mentorservice.saveUser(username, password);
		return "saved";
	}

	@GetMapping("mentorcompleted/findcompleted")
	public @ResponseBody List<MentorCompletedTraining> findcompleted() {
		return mentorservice.searchCompleted();
	}

	@GetMapping("mentorcurrent/findcurrent")
	public @ResponseBody List<MentorCurrentTraining> findcurrent() {
		return mentorservice.searchCurrent();
	}


}
