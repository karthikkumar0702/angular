package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.model.Mentor;
import com.example.demo.model.MentorCompletedTraining;
import com.example.demo.model.MentorCurrentTraining;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.repository.MentorCompletedTrainingRepository;
import com.example.demo.repository.MentorCurrentTrainingRepository;
import com.example.demo.repository.MentorRepository;
@Service
public class MentorService {
	@Autowired
	private MentorRepository mentorRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private MentorCompletedTrainingRepository mentorCompletedRepository;
	@Autowired
	private MentorCurrentTrainingRepository mentorCurrentRepository;
	
	public void saveMentorDetails(Mentor m) {
		mentorRepository.save(m);		
	}
	
	
	public void saveUser(String username,String password) {
		User u=new User();
		u.setUsername(username);
		u.setPassword(password);
		int id=3;
		Role r=roleRepository.findById(id);
		u.setRole(r);	
		userRepository.save(u);
	}
	
	public List<MentorCompletedTraining> searchCompleted() {
		
		return  (List<MentorCompletedTraining>) mentorCompletedRepository.findAll();
		
	}
	public List<MentorCurrentTraining> searchCurrent() {
		
		return (List<MentorCurrentTraining>) mentorCurrentRepository.findAll();
		
	}
	
}
